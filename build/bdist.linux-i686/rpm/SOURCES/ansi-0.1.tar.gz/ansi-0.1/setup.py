from distutils.core import setup

setup( 
  name = "ansi", 
  version = "0.1", 
  url         = "http://areku.ar.funpic.de/",

  author = "Alexander Weigl", 
  author_email = "areku@web.de", 


  py_modules = ["ansi","TerminalController"] 
)
